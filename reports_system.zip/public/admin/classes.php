<?php
declare(strict_types=1);

// Bootstrap
require_once __DIR__ . '/../../config/config.php';

// ---- Auth gate ----
if (!function_exists('is_logged_in') || !is_logged_in()) {
    redirect(base_url('public/'));
    exit;
}
$role = function_exists('get_user_role') ? get_user_role() : null;
$allowedRoles = ['SCHOOL_ADMIN', 'STAFF', 'SUPER_ADMIN'];
if (!$role || !in_array($role, $allowedRoles, true)) {
    redirect(base_url());
    exit;
}
$isSuper = ($role === 'SUPER_ADMIN');

// ---- Page meta ----
$pageTitle       = 'Classes — Admin';
$pageDescription = 'Manage classes: add, edit, assign teacher, delete, search and browse records.';
$bodyClass       = 'dashboard classes-page';

// ---- CSRF helpers ----
if (session_status() !== PHP_SESSION_ACTIVE) { @session_start(); }
if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
function csrf_token(): string { return $_SESSION['csrf']; }
function check_csrf(?string $t): bool { return is_string($t) && hash_equals($_SESSION['csrf'] ?? '', $t); }

// ---- DB helpers ----
function __get_pdo(): PDO {
    if (function_exists('db'))     { $maybe = db();     if ($maybe instanceof PDO) return $maybe; }
    if (function_exists('get_db')) { $maybe = get_db(); if ($maybe instanceof PDO) return $maybe; }
    if (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) return $GLOBALS['pdo'];
    if (isset($GLOBALS['db'])  && $GLOBALS['db']  instanceof PDO) return $GLOBALS['db'];

    $dsn  = defined('DB_DSN')  ? DB_DSN  : 'mysql:host='.(defined('DB_HOST')?DB_HOST:'127.0.0.1').';dbname='.(defined('DB_NAME')?DB_NAME:'').';charset=utf8mb4';
    $user = defined('DB_USER') ? DB_USER : '';
    $pass = defined('DB_PASS') ? DB_PASS : '';
    return new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
}
function __table_exists(PDO $pdo, string $table): bool {
    $stmt = $pdo->query("SHOW TABLES LIKE " . $pdo->quote($table));
    return (bool)$stmt->fetchColumn();
}
function __columns(PDO $pdo, string $table): array {
    $cols = [];
    foreach ($pdo->query("SHOW COLUMNS FROM `{$table}`") as $row) { $cols[] = $row['Field']; }
    return $cols;
}
function __intersect(array $a, array $b): array {
    return array_values(array_intersect($a, $b));
}

/** Resolve current school id (from session; fallback to users.school_id) */
function __current_school_id(PDO $pdo): ?int {
    if (!empty($_SESSION['school_id'])) return (int)$_SESSION['school_id'];
    if (!empty($_SESSION['user_id']) && __table_exists($pdo, 'users')) {
        $ucols = __columns($pdo, 'users');
        if (in_array('school_id', $ucols, true)) {
            $q = $pdo->prepare("SELECT school_id FROM users WHERE id = :id LIMIT 1");
            $q->execute([':id' => (int)$_SESSION['user_id']]);
            $sid = $q->fetchColumn();
            if ($sid !== false && $sid !== null) {
                $_SESSION['school_id'] = (int)$sid;
                return (int)$sid;
            }
        }
    }
    return null;
}

// Staff options (optionally scoped by school)
function __get_staff_options(PDO $pdo, ?int $schoolId, bool $isSuper): array {
    $candidates = [
        ['table' => 'users',    'role_col' => 'role'],
        ['table' => 'staff',    'role_col' => null],
        ['table' => 'teachers', 'role_col' => null],
    ];
    foreach ($candidates as $cand) {
        if (!__table_exists($pdo, $cand['table'])) continue;
        $cols = __columns($pdo, $cand['table']);
        if (!in_array('id', $cols, true)) continue;

        // label
        if (in_array('full_name', $cols, true)) $labelExpr = 'full_name';
        elseif (in_array('name', $cols, true)) $labelExpr = 'name';
        elseif (in_array('first_name', $cols, true) && in_array('last_name', $cols, true)) $labelExpr = "CONCAT(first_name,' ',last_name)";
        elseif (in_array('username', $cols, true)) $labelExpr = 'username';
        elseif (in_array('email', $cols, true)) $labelExpr = 'email';
        else $labelExpr = 'id';

        $w = []; $b = [];
        if ($cand['role_col'] && in_array($cand['role_col'], $cols, true)) {
            $w[] = "`{$cand['role_col']}` IN ('STAFF','TEACHER','teacher','staff')";
        }
        if (!$isSuper && $schoolId !== null && in_array('school_id', $cols, true)) {
            $w[] = "`school_id` = :sid";
            $b[':sid'] = $schoolId;
        }
        $where = $w ? ('WHERE '.implode(' AND ', $w)) : '';
        $sql = "SELECT id, {$labelExpr} AS label FROM `{$cand['table']}` {$where} ORDER BY label LIMIT 500";
        $stmt = empty($b) ? $pdo->query($sql) : (function($pdo,$sql,$b){$s=$pdo->prepare($sql);$s->execute($b);return $s;})($pdo,$sql,$b);
        $rows = $stmt->fetchAll();
        if (!empty($rows)) return ['table'=>$cand['table'],'options'=>$rows];
    }
    return ['table'=>null,'options'=>[]];
}

$pdo          = __get_pdo();
$classesTable = 'classes';

// ---- Flash via session (for PRG) ----
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

// Bail early if table missing
if (!__table_exists($pdo, $classesTable)) {
    include __DIR__ . '/../../views/layouts/header.php';
    echo '<div class="container" style="padding:16px">';
    echo '<div class="alert alert-warning">The table <strong>'.$classesTable.'</strong> was not found. Please import your schema or update <code>$classesTable</code> in this file.</div>';
    echo '</div>';
    include __DIR__ . '/../../views/layouts/footer.php';
    exit;
}

// Columns / feature flags
$allCols         = __columns($pdo, $classesTable);
$hasId           = in_array('id', $allCols, true);
$hasTeacherId    = in_array('teacher_id', $allCols, true);
$hasClassTeacher = in_array('class_teacher', $allCols, true);
$hasUpdatedAt    = in_array('updated_at', $allCols, true);
$hasCreatedAt    = in_array('created_at', $allCols, true);
$hasSchoolId     = in_array('school_id', $allCols, true);
$schoolId        = __current_school_id($pdo);

// Fields we try to insert/update if present
$candidateFields = [
    'name','class_name','code','level','section','stream',
    'class_teacher','teacher_id','capacity','school_id','status',
    'created_at','updated_at',
];

// ---- POST handling with PRG (prevents duplicates on refresh) ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['__action'] ?? '';
    $token  = $_POST['__csrf']   ?? '';

    if (!check_csrf($token)) {
        $_SESSION['flash'] = ['type'=>'danger','msg'=>'Invalid security token. Please try again.'];
        redirect($_SERVER['REQUEST_URI']);
        exit;
    }

    try {
        // CREATE
        if ($action === 'create') {
            $insertCols = __intersect($candidateFields, $allCols);
            if (empty($insertCols)) $insertCols = array_slice($allCols, 0, min(6, count($allCols)));

            $params = []; $ph = [];
            foreach ($insertCols as $c) {
                if ($c === 'school_id' && $hasSchoolId && !$isSuper) {
                    $params[":$c"] = $schoolId; // enforce from session
                } elseif ($c === 'created_at' && $hasCreatedAt) {
                    $params[':created_at'] = date('Y-m-d H:i:s');
                } elseif ($c === 'updated_at' && $hasUpdatedAt) {
                    $params[':updated_at'] = date('Y-m-d H:i:s');
                } else {
                    $params[":$c"] = $_POST[$c] ?? null;
                }
                $ph[] = ":$c";
            }

            $sql = "INSERT INTO `{$classesTable}` (`".implode('`,`',$insertCols)."`) VALUES (".implode(',', $ph).")";
            $pdo->prepare($sql)->execute($params);

            $_SESSION['flash'] = ['type'=>'success','msg'=>'Class added successfully.'];
            redirect($_SERVER['REQUEST_URI']);
            exit;
        }

        // EDIT
        if ($action === 'edit' && $hasId) {
            $id = (int)($_POST['id'] ?? 0);
            if ($id > 0) {
                $editable = __intersect($candidateFields, $allCols);
                // forbid editing these via generic edit; admins cannot change school_id
                $noEdit = ['teacher_id','created_at'];
                if (!$isSuper) $noEdit[] = 'school_id';
                $editable = array_values(array_diff($editable, $noEdit));

                $sets = []; $params = [':id'=>$id];
                foreach ($editable as $col) {
                    if (array_key_exists($col, $_POST)) {
                        $sets[] = "`$col` = :$col";
                        $params[":$col"] = ($_POST[$col] === '') ? null : $_POST[$col];
                    }
                }
                if ($hasUpdatedAt) { $sets[] = "`updated_at` = :updated_at"; $params[':updated_at'] = date('Y-m-d H:i:s'); }

                if ($sets) {
                    $where = "WHERE `id` = :id";
                    if ($hasSchoolId && !$isSuper && $schoolId !== null) {
                        $where .= " AND `school_id` = :sid";
                        $params[':sid'] = $schoolId;
                    }
                    $sql = "UPDATE `{$classesTable}` SET ".implode(',', $sets)." {$where} LIMIT 1";
                    $pdo->prepare($sql)->execute($params);
                }

                $_SESSION['flash'] = ['type'=>'success','msg'=>'Class updated.'];
                redirect($_SERVER['REQUEST_URI']);
                exit;
            }
        }

        // DELETE
        if ($action === 'delete' && $hasId) {
            $id = (int)($_POST['id'] ?? 0);
            if ($id > 0) {
                $params = [':id'=>$id];
                $where  = "WHERE `id` = :id";
                if ($hasSchoolId && !$isSuper && $schoolId !== null) {
                    $where .= " AND `school_id` = :sid";
                    $params[':sid'] = $schoolId;
                }
                $pdo->prepare("DELETE FROM `{$classesTable}` {$where} LIMIT 1")->execute($params);
                $_SESSION['flash'] = ['type'=>'success','msg'=>'Class deleted.'];
            }
            redirect($_SERVER['REQUEST_URI']);
            exit;
        }

        // ASSIGN TEACHER
        if ($action === 'assign' && $hasId) {
            $id = (int)($_POST['id'] ?? 0);
            $teacherId   = isset($_POST['teacher_id'])   && $_POST['teacher_id']   !== '' ? (int)$_POST['teacher_id']   : null;
            $teacherName = isset($_POST['class_teacher']) && $_POST['class_teacher'] !== '' ? trim((string)$_POST['class_teacher']) : null;

            if ($id > 0) {
                $sets = []; $params = [':id'=>$id];
                if ($hasTeacherId && $teacherId !== null)   { $sets[] = "`teacher_id` = :teacher_id";       $params[':teacher_id'] = $teacherId; }
                if ($hasClassTeacher && $teacherName !== null){ $sets[] = "`class_teacher` = :class_teacher"; $params[':class_teacher'] = $teacherName; }
                if ($hasUpdatedAt)                          { $sets[] = "`updated_at` = :updated_at";       $params[':updated_at'] = date('Y-m-d H:i:s'); }

                if ($sets) {
                    $where = "WHERE `id` = :id";
                    if ($hasSchoolId && !$isSuper && $schoolId !== null) {
                        $where .= " AND `school_id` = :sid";
                        $params[':sid'] = $schoolId;
                    }
                    $sql = "UPDATE `{$classesTable}` SET ".implode(',', $sets)." {$where} LIMIT 1";
                    $pdo->prepare($sql)->execute($params);
                    $_SESSION['flash'] = ['type'=>'success','msg'=>'Teacher assigned to class.'];
                } else {
                    $_SESSION['flash'] = ['type'=>'warning','msg'=>'No suitable teacher fields found (add `teacher_id` and/or `class_teacher`).'];
                }
            }
            redirect($_SERVER['REQUEST_URI']);
            exit;
        }

        $_SESSION['flash'] = ['type'=>'warning','msg'=>'Nothing to do.'];
        redirect($_SERVER['REQUEST_URI']);
        exit;

    } catch (Throwable $e) {
        $_SESSION['flash'] = ['type'=>'danger','msg'=>'Error: '.htmlspecialchars($e->getMessage())];
        redirect($_SERVER['REQUEST_URI']);
        exit;
    }
}

// ---- GET: list (scoped) ----
$q      = trim((string)($_GET['q'] ?? ''));
$page   = max(1, (int)($_GET['page'] ?? 1));
$per    = 20;
$offset = ($page - 1) * $per;

// Searchable columns
$searchable = __intersect(
    ['name','class_name','code','level','section','stream','class_teacher','status'],
    $allCols
);

// Build WHERE (scope + search)
$whereParts = []; $bind = [];
if ($hasSchoolId && !$isSuper && $schoolId !== null) {
    $whereParts[] = "`{$classesTable}`.`school_id` = :sid";
    $bind[':sid'] = $schoolId;
}
if ($q !== '' && $searchable) {
    $parts = [];
    foreach ($searchable as $col) { $parts[] = "`$col` LIKE :q"; }
    $whereParts[] = '(' . implode(' OR ', $parts) . ')';
    $bind[':q'] = '%'.$q.'%';
}
$whereSql = $whereParts ? 'WHERE '.implode(' AND ', $whereParts) : '';

// Count
$c = $pdo->prepare("SELECT COUNT(*) FROM `{$classesTable}` {$whereSql}");
$c->execute($bind);
$total = (int)$c->fetchColumn();

// Columns to display
$preferred = __intersect(
    ['id','name','class_name','code','level','section','stream','class_teacher','teacher_id','capacity','status','created_at'],
    $allCols
);
if (empty($preferred)) $preferred = array_slice($allCols, 0, min(8, count($allCols)));

// Select rows
$sel = $pdo->prepare("SELECT `".implode('`,`',$preferred)."` FROM `{$classesTable}` {$whereSql} ORDER BY ".($hasId?'`id` DESC':'1')." LIMIT :lim OFFSET :off");
foreach ($bind as $k=>$v) { $sel->bindValue($k, $v, is_int($v)?PDO::PARAM_INT:PDO::PARAM_STR); }
$sel->bindValue(':lim', $per, PDO::PARAM_INT);
$sel->bindValue(':off', $offset, PDO::PARAM_INT);
$sel->execute();
$rows  = $sel->fetchAll();
$pages = (int)ceil($total / $per);

// Staff options for assign
$staffData    = __get_staff_options($pdo, $schoolId, $isSuper);
$staffOptions = $staffData['options'];

// ---- Render ----
include __DIR__ . '/../../views/layouts/header.php';
?>
<style>
  .classes-page .page-head{display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;padding:16px;border-bottom:1px solid #223146;background:linear-gradient(180deg,#0f1626,#121c31);position:sticky;top:64px;z-index:10}
  .classes-page h1{margin:0;font-size:20px;font-weight:800;letter-spacing:.2px}
  .classes-page .actions{display:flex;gap:8px;align-items:center}
  .classes-page .btn{display:inline-flex;align-items:center;gap:8px;border-radius:10px;padding:10px 12px;border:1px solid #223146;background:#15253c;color:#eaf2ff;text-decoration:none;font-weight:700;cursor:pointer}
  .classes-page .btn svg{width:16px;height:16px}
  .classes-page .btn-primary{background:linear-gradient(90deg,#00c4cc,#00cc88);color:#062117;border:none}
  .classes-page .btn-danger{background:#741f2a;border-color:#7f2a33}
  .classes-page .btn:hover{transform:translateY(-1px);box-shadow:0 10px 22px rgba(0,0,0,.28)}
  .classes-page .search{display:flex;gap:8px;align-items:center;padding:16px;border-bottom:1px solid #223146;background:#0f1626}
  .classes-page input[type="text"],.classes-page select{background:#0e1524;border:1px solid #223146;color:#eaf2ff;border-radius:10px;padding:10px 12px}
  .classes-page .table-wrap{padding:16px;overflow:auto}
  .classes-page table{width:100%;border-collapse:collapse;min-width:840px}
  .classes-page th,.classes-page td{border-bottom:1px solid #223146;padding:10px;text-align:left;vertical-align:middle}
  .classes-page th{font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:#aabbd3}
  .classes-page tbody tr:hover{background:#111c2d}
  .classes-page .actions-col{white-space:nowrap}
  .classes-page .empty{padding:24px;text-align:center;color:#aabbd3;border:1px dashed #223146;border-radius:12px;background:#0e1524}
  .classes-page .pagination{display:flex;gap:6px;align-items:center;justify-content:flex-end;padding:16px}
  .classes-page .page-link{padding:6px 10px;border-radius:8px;border:1px solid #223146;text-decoration:none;color:#eaf2ff;background:#14243a}
  .classes-page .page-link.active{background:linear-gradient(90deg,#00c4cc,#00cc88);color:#062117;border:none}
  .classes-page .modal{position:fixed;inset:0;display:none;align-items:center;justify-content:center;z-index:80;background:rgba(6,10,18,.6)}
  .classes-page .modal.open{display:flex}
  .classes-page .modal-card{width:100%;max-width:820px;background:#0e1524;border:1px solid #223146;border-radius:16px;box-shadow:0 30px 80px rgba(0,0,0,.45)}
  .classes-page .modal-head{padding:14px 16px;border-bottom:1px solid #223146;display:flex;align-items:center;justify-content:space-between;background:linear-gradient(180deg,#0f1626,#121c31)}
  .classes-page .modal-body{padding:16px;display:grid;gap:12px;grid-template-columns:repeat(auto-fit,minmax(220px,1fr))}
  .classes-page .modal-actions{padding:14px 16px;border-top:1px solid #223146;display:flex;justify-content:flex-end;gap:8px}
  .classes-page .form-control label{font-size:12px;color:#aabbd3;display:block;margin-bottom:6px}
  .classes-page .form-control input,.classes-page .form-control select{width:100%;background:#0e1524;border:1px solid #223146;color:#eaf2ff;border-radius:10px;padding:10px 12px}
  .alert{border-radius:12px;padding:10px 12px;margin:16px}
  .alert-success{background:rgba(0,204,136,.1);border:1px solid #1e7f5d;color:#9ae8ce}
  .alert-danger{background:rgba(255,71,87,.08);border:1px solid #7f2a33;color:#ffb3bb}
  .alert-warning{background:rgba(255,193,7,.08);border:1px solid #80630f;color:#ffe199}
</style>

<section class="classes-page">
  <div class="page-head">
    <h1>Classes</h1>
    <div class="actions">
      <button class="btn btn-primary" id="btnOpenModal" type="button">
        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M11 11V5h2v6h6v2h-6v6h-2v-6H5v-2z"/></svg>
        Add Class
      </button>
    </div>
  </div>

  <?php if ($flash): ?>
    <div class="alert alert-<?php echo htmlspecialchars($flash['type']); ?>">
      <?php echo $flash['msg']; ?>
    </div>
  <?php endif; ?>

  <form class="search" method="get" action="">
    <input type="text" name="q" value="<?php echo htmlspecialchars($q); ?>" placeholder="Search name, code, level, stream…" />
    <button class="btn" type="submit">
      <svg viewBox="0 0 24 24" fill="currentColor"><path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zM9.5 14A4.5 4.5 0 1 1 14 9.5 4.505 4.505 0 0 1 9.5 14z"/></svg>
      Search
    </button>
  </form>

  <div class="table-wrap">
    <?php if ($total === 0): ?>
      <div class="empty">No classes found<?php echo $q ? ' for "<strong>'.htmlspecialchars($q).'</strong>"' : ''; ?>.</div>
    <?php else: ?>
      <table>
        <thead>
          <tr>
            <?php foreach ($preferred as $col): ?>
              <th><?php echo ucwords(str_replace('_',' ', $col)); ?></th>
            <?php endforeach; ?>
            <?php if ($hasId): ?>
              <th class="actions-col">Actions</th>
            <?php endif; ?>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($rows as $r): ?>
            <tr>
              <?php foreach ($preferred as $col): ?>
                <td><?php
                  $val = $r[$col];
                  echo htmlspecialchars(is_scalar($val) ? (string)$val : json_encode($val));
                ?></td>
              <?php endforeach; ?>

              <?php if ($hasId): ?>
                <td class="actions-col">
                  <!-- Edit -->
                  <button
                    class="btn"
                    type="button"
                    title="Edit"
                    data-act="edit"
                    data-row='<?php echo htmlspecialchars(json_encode($r), ENT_QUOTES, 'UTF-8'); ?>'
                  >
                    <svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a1.003 1.003 0 0 0 0-1.41l-2.34-2.34a1.003 1.003 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>
                    Edit
                  </button>

                  <!-- Assign (teacher) -->
                  <button
                    class="btn"
                    type="button"
                    title="Assign Teacher"
                    data-act="assign"
                    data-id="<?php echo (int)$r['id']; ?>"
                    data-current-name="<?php echo htmlspecialchars((string)($r['class_teacher'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"
                    data-current-teacher-id="<?php echo htmlspecialchars((string)($r['teacher_id'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"
                  >
                    <svg viewBox="0 0 24 24" fill="currentColor">
                      <path d="M12 12a5 5 0 1 0-5-5 5 5 0 0 0 5 5zm0 2c-4 0-7 2-7 5v1h10v-1c0-1.66 1.34-3 3-3h1v-2z"/>
                      <path d="M5 10v2H3v2h2v2h2v-2h2v-2H7v-2z"/>
                    </svg>
                    Assign
                  </button>

                  <!-- Delete -->
                  <form method="post" style="display:inline" onsubmit="return confirm('Delete this class? This cannot be undone.');">
                    <input type="hidden" name="__csrf" value="<?php echo csrf_token(); ?>">
                    <input type="hidden" name="__action" value="delete">
                    <input type="hidden" name="id" value="<?php echo (int)$r['id']; ?>">
                    <button class="btn btn-danger" type="submit" title="Delete">
                      <svg viewBox="0 0 24 24" fill="currentColor"><path d="M9 3h6l1 2h5v2H3V5h5l1-2zm1 7h2v8h-2v-8zm4 0h2v8h-2v-8zM7 10h2v8H7v-8z"/></svg>
                      Delete
                    </button>
                  </form>
                </td>
              <?php endif; ?>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>

  <?php if ($pages > 1): ?>
    <div class="pagination">
      <?php for ($i = 1; $i <= $pages; $i++):
        $url = '?'.http_build_query(['q'=>$q,'page'=>$i]);
        $cls = 'page-link'.($i === $page ? ' active' : '');
      ?>
        <a class="<?php echo $cls; ?>" href="<?php echo $url; ?>"><?php echo $i; ?></a>
      <?php endfor; ?>
    </div>
  <?php endif; ?>
</section>

<!-- Add Class Modal -->
<div class="modal" id="modalAdd">
  <div class="modal-card">
    <div class="modal-head">
      <strong>Add Class</strong>
      <button class="btn" id="btnCloseModal" type="button">Close</button>
    </div>

    <form method="post" class="modal-body" id="formAdd">
      <input type="hidden" name="__action" value="create" />
      <input type="hidden" name="__csrf" value="<?php echo csrf_token(); ?>" />
      <!-- school_id enforced on server; no field here -->
      <div class="form-control"><label>Class Name</label><input type="text" name="name" placeholder="e.g., Senior One" required /></div>
      <div class="form-control"><label>Alternate Name</label><input type="text" name="class_name" placeholder="e.g., S1" /></div>
      <div class="form-control"><label>Code</label><input type="text" name="code" placeholder="e.g., S1A" /></div>
      <div class="form-control"><label>Level</label><input type="text" name="level" placeholder="O-Level / A-Level" /></div>
      <div class="form-control"><label>Section</label><input type="text" name="section" placeholder="e.g., East Wing" /></div>
      <div class="form-control"><label>Stream</label><input type="text" name="stream" placeholder="e.g., Blue / Red" /></div>
      <div class="form-control"><label>Class Teacher (name)</label><input type="text" name="class_teacher" placeholder="e.g., Mr. Okello" /></div>
      <div class="form-control"><label>Teacher ID</label><input type="text" name="teacher_id" /></div>
      <div class="form-control"><label>Capacity</label><input type="number" name="capacity" min="0" /></div>
      <div class="form-control"><label>Status</label><input type="text" name="status" placeholder="active / inactive" /></div>
    </form>

    <div class="modal-actions">
      <button class="btn" id="btnCancel" type="button">Cancel</button>
      <button class="btn btn-primary" id="btnSaveAdd" form="formAdd">Save</button>
    </div>
  </div>
</div>

<!-- Edit Class Modal -->
<div class="modal" id="modalEdit">
  <div class="modal-card">
    <div class="modal-head">
      <strong>Edit Class</strong>
      <button class="btn" id="btnCloseEdit" type="button">Close</button>
    </div>

    <form method="post" class="modal-body" id="formEdit">
      <input type="hidden" name="__action" value="edit" />
      <input type="hidden" name="__csrf" value="<?php echo csrf_token(); ?>" />
      <input type="hidden" name="id" id="edit_id" />

      <div class="form-control"><label>Class Name</label><input type="text" name="name" id="edit_name" required /></div>
      <div class="form-control"><label>Alternate Name</label><input type="text" name="class_name" id="edit_class_name" /></div>
      <div class="form-control"><label>Code</label><input type="text" name="code" id="edit_code" /></div>
      <div class="form-control"><label>Level</label><input type="text" name="level" id="edit_level" /></div>
      <div class="form-control"><label>Section</label><input type="text" name="section" id="edit_section" /></div>
      <div class="form-control"><label>Stream</label><input type="text" name="stream" id="edit_stream" /></div>
      <div class="form-control"><label>Class Teacher (name)</label><input type="text" name="class_teacher" id="edit_class_teacher" /></div>
      <div class="form-control"><label>Capacity</label><input type="number" name="capacity" id="edit_capacity" /></div>
      <div class="form-control"><label>Status</label><input type="text" name="status" id="edit_status" /></div>
    </form>

    <div class="modal-actions">
      <button class="btn" id="btnCancelEdit" type="button">Cancel</button>
      <button class="btn btn-primary" id="btnSaveEdit" form="formEdit">Update</button>
    </div>
  </div>
</div>

<!-- Assign Teacher Modal -->
<div class="modal" id="modalAssign">
  <div class="modal-card">
    <div class="modal-head">
      <strong>Assign Teacher to Class</strong>
      <button class="btn" id="btnCloseAssign" type="button">Close</button>
    </div>

    <form method="post" class="modal-body" id="formAssign">
      <input type="hidden" name="__action" value="assign" />
      <input type="hidden" name="__csrf" value="<?php echo csrf_token(); ?>" />
      <input type="hidden" name="id" id="assign_id" />

      <?php if (!empty($staffOptions) && $hasTeacherId): ?>
        <div class="form-control">
          <label>Select Staff/Teacher</label>
          <select name="teacher_id" id="assign_teacher_id">
            <option value="">— select —</option>
            <?php foreach ($staffOptions as $opt): ?>
              <option value="<?php echo (int)$opt['id']; ?>"><?php echo htmlspecialchars((string)$opt['label']); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      <?php endif; ?>

      <?php if ($hasClassTeacher): ?>
        <div class="form-control">
          <label>Teacher Name (for report display)</label>
          <input type="text" name="class_teacher" id="assign_class_teacher" placeholder="e.g., Mr. Okello" />
        </div>
      <?php endif; ?>

      <?php if (empty($staffOptions) && !$hasClassTeacher): ?>
        <div class="form-control">
          <label>Note</label>
          <input type="text" value="No staff/teacher table or class_teacher column found." disabled>
        </div>
      <?php endif; ?>
    </form>

    <div class="modal-actions">
      <button class="btn" id="btnCancelAssign" type="button">Cancel</button>
      <button class="btn btn-primary" id="btnSaveAssign" form="formAssign">Assign</button>
    </div>
  </div>
</div>

<script>
  (function(){
    // Add
    const modalAdd  = document.getElementById('modalAdd');
    const addOpen   = document.getElementById('btnOpenModal');
    const addClose  = document.getElementById('btnCloseModal');
    const addCancel = document.getElementById('btnCancel');
    function showAdd(){ modalAdd.classList.add('open'); const b=document.getElementById('btnSaveAdd'); if(b) b.disabled=false; }
    function hideAdd(){ modalAdd.classList.remove('open'); }
    addOpen?.addEventListener('click', showAdd);
    addClose?.addEventListener('click', hideAdd);
    addCancel?.addEventListener('click', hideAdd);
    modalAdd?.addEventListener('click', (e)=>{ if (e.target === modalAdd) hideAdd(); });

    // Edit
    const modalEdit  = document.getElementById('modalEdit');
    const editClose  = document.getElementById('btnCloseEdit');
    const editCancel = document.getElementById('btnCancelEdit');
    function showEdit(){ modalEdit.classList.add('open'); const b=document.getElementById('btnSaveEdit'); if(b) b.disabled=false; }
    function hideEdit(){ modalEdit.classList.remove('open'); }
    editClose?.addEventListener('click', hideEdit);
    editCancel?.addEventListener('click', hideEdit);
    modalEdit?.addEventListener('click', (e)=>{ if (e.target === modalEdit) hideEdit(); });

    // Assign
    const modalAssign  = document.getElementById('modalAssign');
    const assignClose  = document.getElementById('btnCloseAssign');
    const assignCancel = document.getElementById('btnCancelAssign');
    function showAssign(){ modalAssign.classList.add('open'); const b=document.getElementById('btnSaveAssign'); if(b) b.disabled=false; }
    function hideAssign(){ modalAssign.classList.remove('open'); }
    assignClose?.addEventListener('click', hideAssign);
    assignCancel?.addEventListener('click', hideAssign);
    modalAssign?.addEventListener('click', (e)=>{ if (e.target === modalAssign) hideAssign(); });

    // Row action handlers
    document.addEventListener('click', function(e){
      const t = e.target.closest('button');
      if (!t) return;
      const act = t.getAttribute('data-act');

      if (act === 'edit') {
        const raw = t.getAttribute('data-row');
        if (!raw) return;
        try {
          const row = JSON.parse(raw);
          const setVal = (id, v) => { const el = document.getElementById(id); if (el) el.value = v ?? ''; };
          setVal('edit_id', row.id ?? '');
          setVal('edit_name', row.name ?? '');
          setVal('edit_class_name', row.class_name ?? '');
          setVal('edit_code', row.code ?? '');
          setVal('edit_level', row.level ?? '');
          setVal('edit_section', row.section ?? '');
          setVal('edit_stream', row.stream ?? '');
          setVal('edit_class_teacher', row.class_teacher ?? '');
          setVal('edit_capacity', row.capacity ?? '');
          setVal('edit_status', row.status ?? '');
          showEdit();
        } catch(err){}
      }

      if (act === 'assign') {
        const id   = t.getAttribute('data-id') || '';
        const name = t.getAttribute('data-current-name') || '';
        const tid  = t.getAttribute('data-current-teacher-id') || '';
        const idEl   = document.getElementById('assign_id');
        const nameEl = document.getElementById('assign_class_teacher');
        const tidEl  = document.getElementById('assign_teacher_id');
        if (idEl) idEl.value = id;
        if (nameEl) nameEl.value = name;
        if (tidEl) tidEl.value = tid;
        showAssign();
      }
    });

    // Disable submit buttons on submit (guard double click)
    document.getElementById('formAdd')?.addEventListener('submit', ()=>{ const b=document.getElementById('btnSaveAdd'); if(b) b.disabled=true; });
    document.getElementById('formEdit')?.addEventListener('submit', ()=>{ const b=document.getElementById('btnSaveEdit'); if(b) b.disabled=true; });
    document.getElementById('formAssign')?.addEventListener('submit', ()=>{ const b=document.getElementById('btnSaveAssign'); if(b) b.disabled=true; });

    // Escape closes
    document.addEventListener('keydown', (e)=>{ if (e.key === 'Escape') { hideAdd(); hideEdit(); hideAssign(); }});
  })();
</script>

<?php
// Footer
include __DIR__ . '/../../views/layouts/footer.php';
