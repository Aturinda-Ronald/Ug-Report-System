<?php
/**
 * Test file to verify URL generation works correctly
 * Access this file via both localhost and IP:port to test
 */

// Include config to test our functions
require_once __DIR__ . '/config/config.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>URL Generation Test</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
        .container { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .test-section { margin: 20px 0; padding: 15px; background: #f8f9fa; border-radius: 5px; }
        .url-test { margin: 10px 0; padding: 10px; background: #e9ecef; border-radius: 3px; }
        .success { color: #28a745; }
        .info { color: #17a2b8; }
        h1 { color: #343a40; }
        h2 { color: #495057; margin-top: 30px; }
        code { background: #f1f3f4; padding: 2px 6px; border-radius: 3px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔧 Uganda Results System - URL Generation Test</h1>

        <div class="test-section">
            <h2>Current Request Information</h2>
            <div class="url-test">
                <strong>Current URL:</strong> <code><?php echo $_SERVER['REQUEST_URI'] ?? 'N/A'; ?></code>
            </div>
            <div class="url-test">
                <strong>HTTP Host:</strong> <code><?php echo $_SERVER['HTTP_HOST'] ?? 'N/A'; ?></code>
            </div>
            <div class="url-test">
                <strong>Script Name:</strong> <code><?php echo $_SERVER['SCRIPT_NAME'] ?? 'N/A'; ?></code>
            </div>
            <div class="url-test">
                <strong>Server Protocol:</strong> <code><?php echo (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'HTTPS' : 'HTTP'); ?></code>
            </div>
        </div>

        <div class="test-section">
            <h2>Generated URLs (using base_url function)</h2>
            <div class="url-test">
                <strong>Base URL:</strong> <code><?php echo base_url(); ?></code>
            </div>
            <div class="url-test">
                <strong>Admin Login:</strong> <code><?php echo base_url('auth/login-admin.php'); ?></code>
            </div>
            <div class="url-test">
                <strong>Student Login:</strong> <code><?php echo base_url('auth/login-student.php'); ?></code>
            </div>
            <div class="url-test">
                <strong>Admin Dashboard:</strong> <code><?php echo base_url('admin/'); ?></code>
            </div>
            <div class="url-test">
                <strong>Student Dashboard:</strong> <code><?php echo base_url('student/'); ?></code>
            </div>
        </div>

        <div class="test-section">
            <h2>Test Navigation Links</h2>
            <p class="info">Click these links to test if routing works correctly:</p>
            <div class="url-test">
                <a href="<?php echo base_url(); ?>" target="_blank">🏠 Home Page</a>
            </div>
            <div class="url-test">
                <a href="<?php echo base_url('auth/login-admin.php'); ?>" target="_blank">👨‍💼 Admin Login</a>
            </div>
            <div class="url-test">
                <a href="<?php echo base_url('auth/login-student.php'); ?>" target="_blank">🎓 Student Login</a>
            </div>
        </div>

        <div class="test-section">
            <h2>APP_URL Constant</h2>
            <div class="url-test">
                <strong>APP_URL:</strong> <code><?php echo APP_URL; ?></code>
            </div>
        </div>

        <div class="test-section success">
            <h2>✅ How to Test</h2>
            <ol>
                <li>Access this page via <strong>localhost</strong>: <code>localhost/reports_system/test-url-fix.php</code></li>
                <li>Access this page via <strong>IP:port</strong>: <code>172.16.21.100:8082/test-url-fix.php</code> (NO /reports_system)</li>
                <li>Compare the generated URLs:</li>
                <ul>
                    <li><strong>Localhost</strong>: URLs should include <code>/reports_system/public/</code></li>
                    <li><strong>IP:port</strong>: URLs should be clean with NO subdirectories</li>
                </ul>
                <li>Click the test links to verify navigation works correctly</li>
                <li>Test the actual system: <code>172.16.21.100:8082/</code> should work without errors</li>
            </ol>
        </div>
    </div>
</body>
</html>
