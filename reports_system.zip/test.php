<?php
/**
 * Uganda Results System - Setup Test & Diagnostics
 * Use this to verify your installation is working correctly
 */

// Prevent caching
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

echo "<h1>Uganda Results System - Setup Diagnostics</h1>";
echo "<style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 40px; }
    .pass { color: #059669; font-weight: bold; }
    .fail { color: #dc2626; font-weight: bold; }
    .warn { color: #d97706; font-weight: bold; }
    .section { margin: 30px 0; padding: 20px; border: 1px solid #e5e7eb; border-radius: 8px; }
    .command { background: #f3f4f6; padding: 10px; border-radius: 4px; font-family: monospace; margin: 10px 0; }
    table { border-collapse: collapse; width: 100%; margin: 15px 0; }
    th, td { border: 1px solid #e5e7eb; padding: 8px 12px; text-align: left; }
    th { background: #f9fafb; }
</style>";

// Test 1: PHP Version and Environment
echo "<div class='section'>";
echo "<h2>1. PHP Environment Check</h2>";
echo "<table>";
echo "<tr><th>Check</th><th>Status</th><th>Details</th></tr>";

// PHP Version
$phpVersion = PHP_VERSION;
$phpOk = version_compare($phpVersion, '8.0.0', '>=');
echo "<tr><td>PHP Version</td><td class='" . ($phpOk ? 'pass' : 'fail') . "'>" . ($phpOk ? '✅ PASS' : '❌ FAIL') . "</td><td>$phpVersion</td></tr>";

// Required Extensions
$extensions = ['pdo', 'pdo_mysql', 'mbstring', 'openssl', 'json', 'session', 'filter'];
foreach ($extensions as $ext) {
    $loaded = extension_loaded($ext);
    echo "<tr><td>$ext extension</td><td class='" . ($loaded ? 'pass' : 'fail') . "'>" . ($loaded ? '✅ PASS' : '❌ FAIL') . "</td><td>" . ($loaded ? 'Loaded' : 'Missing') . "</td></tr>";
}

// Memory Limit
$memoryLimit = ini_get('memory_limit');
echo "<tr><td>Memory Limit</td><td class='pass'>✅ INFO</td><td>$memoryLimit</td></tr>";

// File Upload
$maxFileSize = ini_get('upload_max_filesize');
$postMaxSize = ini_get('post_max_size');
echo "<tr><td>File Upload</td><td class='pass'>✅ INFO</td><td>Max: $maxFileSize, Post: $postMaxSize</td></tr>";

echo "</table>";
echo "</div>";

// Test 2: File Structure
echo "<div class='section'>";
echo "<h2>2. File Structure Check</h2>";
echo "<table>";
echo "<tr><th>File/Directory</th><th>Status</th><th>Permissions</th></tr>";

$requiredPaths = [
    'config/config.php' => 'file',
    'config/constants.php' => 'file',
    'database/schema.sql' => 'file',
    'database/seed.sql' => 'file',
    'public/index.php' => 'file',
    'public/auth/login-admin.php' => 'file',
    'public/auth/login-student.php' => 'file',
    'app/Models/BaseModel.php' => 'file',
    'app/Models/User.php' => 'file',
    'assets/css/app.css' => 'file',
    'assets/js/app.js' => 'file',
    'assets/uploads' => 'dir',
    'assets/exports' => 'dir',
    'assets/img/logos' => 'dir',
    'assets/img/avatars' => 'dir'
];

foreach ($requiredPaths as $path => $type) {
    $exists = ($type === 'file') ? file_exists($path) : is_dir($path);
    $permissions = $exists ? (is_writable($path) ? 'Writable' : 'Read-only') : 'N/A';
    $status = $exists ? '✅ EXISTS' : '❌ MISSING';
    $class = $exists ? 'pass' : 'fail';

    if ($exists && in_array($path, ['assets/uploads', 'assets/exports', 'assets/img/logos', 'assets/img/avatars']) && !is_writable($path)) {
        $status = '⚠️ WARN';
        $class = 'warn';
        $permissions .= ' (Should be writable)';
    }

    echo "<tr><td>$path</td><td class='$class'>$status</td><td>$permissions</td></tr>";
}

echo "</table>";
echo "</div>";

// Test 3: Configuration Loading
echo "<div class='section'>";
echo "<h2>3. Configuration Test</h2>";

try {
    require_once 'config/config.php';
    echo "<p class='pass'>✅ Configuration loaded successfully</p>";

    echo "<table>";
    echo "<tr><th>Setting</th><th>Value</th></tr>";
    echo "<tr><td>Database Host</td><td>" . DB_HOST . "</td></tr>";
    echo "<tr><td>Database Name</td><td>" . DB_NAME . "</td></tr>";
    echo "<tr><td>Database User</td><td>" . DB_USER . "</td></tr>";
    echo "<tr><td>App Name</td><td>" . APP_NAME . "</td></tr>";
    echo "<tr><td>App Version</td><td>" . APP_VERSION . "</td></tr>";
    echo "</table>";

} catch (Exception $e) {
    echo "<p class='fail'>❌ Configuration error: " . htmlspecialchars($e->getMessage()) . "</p>";
}
echo "</div>";

// Test 4: Database Connection
echo "<div class='section'>";
echo "<h2>4. Database Connection Test</h2>";

try {
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);

    echo "<p class='pass'>✅ Database connection successful</p>";

    // Check tables
    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);

    echo "<table>";
    echo "<tr><th>Database Check</th><th>Status</th><th>Details</th></tr>";
    echo "<tr><td>Tables Found</td><td class='pass'>✅ " . count($tables) . "</td><td>" . implode(', ', array_slice($tables, 0, 5)) . (count($tables) > 5 ? '...' : '') . "</td></tr>";

    if (count($tables) > 0) {
        // Check for key tables
        $expectedTables = ['schools', 'users', 'students', 'subjects', 'classes'];
        foreach ($expectedTables as $table) {
            $exists = in_array($table, $tables);
            echo "<tr><td>Table: $table</td><td class='" . ($exists ? 'pass' : 'fail') . "'>" . ($exists ? '✅ EXISTS' : '❌ MISSING') . "</td><td>" . ($exists ? 'Found' : 'Not found') . "</td></tr>";
        }

        // Check sample data
        if (in_array('schools', $tables)) {
            $stmt = $pdo->query("SELECT COUNT(*) as count FROM schools");
            $schoolCount = $stmt->fetch()['count'];
            echo "<tr><td>Sample Schools</td><td class='pass'>✅ " . $schoolCount . "</td><td>Schools in database</td></tr>";
        }

        if (in_array('students', $tables)) {
            $stmt = $pdo->query("SELECT COUNT(*) as count FROM students");
            $studentCount = $stmt->fetch()['count'];
            echo "<tr><td>Sample Students</td><td class='pass'>✅ " . $studentCount . "</td><td>Students in database</td></tr>";
        }

        if (in_array('users', $tables)) {
            $stmt = $pdo->query("SELECT COUNT(*) as count FROM users");
            $userCount = $stmt->fetch()['count'];
            echo "<tr><td>System Users</td><td class='pass'>✅ " . $userCount . "</td><td>Users in database</td></tr>";
        }
    } else {
        echo "<tr><td>Database Status</td><td class='warn'>⚠️ EMPTY</td><td>Need to import schema.sql and seed.sql</td></tr>";
    }

    echo "</table>";

} catch (Exception $e) {
    echo "<p class='fail'>❌ Database connection failed: " . htmlspecialchars($e->getMessage()) . "</p>";

    echo "<div class='command'>";
    echo "<strong>To fix database issues:</strong><br>";
    echo "1. Start MySQL in XAMPP Control Panel<br>";
    echo "2. Open phpMyAdmin: <a href='http://localhost/phpmyadmin' target='_blank'>http://localhost/phpmyadmin</a><br>";
    echo "3. Create database: <code>CREATE DATABASE uganda_results CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;</code><br>";
    echo "4. Import database/schema.sql first, then database/seed.sql";
    echo "</div>";
}
echo "</div>";

// Test 5: URL Access Test
echo "<div class='section'>";
echo "<h2>5. URL Access Test</h2>";

$baseUrl = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['REQUEST_URI']);
$baseUrl = rtrim($baseUrl, '/');

echo "<table>";
echo "<tr><th>Page</th><th>URL</th><th>Action</th></tr>";

$testUrls = [
    'Landing Page' => '/public/',
    'Admin Login' => '/public/auth/login-admin.php',
    'Student Login' => '/public/auth/login-student.php',
    'Admin Dashboard' => '/public/admin/',
    'Student Portal' => '/public/student/',
    'Super Admin' => '/public/super/'
];

foreach ($testUrls as $name => $path) {
    $fullUrl = $baseUrl . $path;
    echo "<tr><td>$name</td><td><code>$fullUrl</code></td><td><a href='$fullUrl' target='_blank' style='color: #059669; text-decoration: none;'>→ Test Link</a></td></tr>";
}

echo "</table>";
echo "</div>";

// Test 6: Installation Guide
echo "<div class='section'>";
echo "<h2>6. Quick Setup Guide</h2>";

echo "<h3>Database Setup (if needed):</h3>";
echo "<div class='command'>";
echo "1. Open phpMyAdmin: <a href='http://localhost/phpmyadmin' target='_blank'>http://localhost/phpmyadmin</a><br>";
echo "2. Create database: uganda_results<br>";
echo "3. Import files in order:<br>";
echo "   - First: database/schema.sql<br>";
echo "   - Then: database/seed.sql";
echo "</div>";

echo "<h3>Test Login Credentials:</h3>";
echo "<table>";
echo "<tr><th>Role</th><th>Login Page</th><th>Credentials</th></tr>";
echo "<tr><td>Super Admin</td><td><a href='{$baseUrl}/public/auth/login-admin.php' target='_blank'>Admin Login</a></td><td>Email: super@uganda-results.com<br>Password: admin123</td></tr>";
echo "<tr><td>School Admin</td><td><a href='{$baseUrl}/public/auth/login-admin.php' target='_blank'>Admin Login</a></td><td>Email: admin@makererecollege.ug<br>Password: admin123</td></tr>";
echo "<tr><td>Student</td><td><a href='{$baseUrl}/public/auth/login-student.php' target='_blank'>Student Login</a></td><td>School: Makerere College School<br>Index: U001/2024<br>Password: student123</td></tr>";
echo "</table>";

echo "<h3>File Permissions (Linux/Mac):</h3>";
echo "<div class='command'>";
echo "chmod 755 assets/uploads/<br>";
echo "chmod 755 assets/exports/<br>";
echo "chmod 755 assets/img/logos/<br>";
echo "chmod 755 assets/img/avatars/";
echo "</div>";

echo "</div>";

// Summary
echo "<div class='section'>";
echo "<h2>7. Summary</h2>";

$allGood = true;
$issues = [];

// Check critical items
if (!$phpOk) {
    $allGood = false;
    $issues[] = "PHP version needs to be 8.0 or higher";
}

if (!extension_loaded('pdo_mysql')) {
    $allGood = false;
    $issues[] = "MySQL PDO extension is missing";
}

if (!file_exists('config/config.php')) {
    $allGood = false;
    $issues[] = "Configuration file is missing";
}

if ($allGood) {
    echo "<p class='pass' style='font-size: 18px;'>🎉 <strong>System appears to be ready!</strong></p>";
    echo "<p>You can now access the main application:</p>";
    echo "<p><a href='{$baseUrl}/public/' style='background: #059669; color: white; padding: 10px 20px; text-decoration: none; border-radius: 6px; font-weight: bold;'>→ Open Uganda Results System</a></p>";
} else {
    echo "<p class='fail' style='font-size: 18px;'>⚠️ <strong>Issues found that need to be fixed:</strong></p>";
    echo "<ul>";
    foreach ($issues as $issue) {
        echo "<li class='fail'>$issue</li>";
    }
    echo "</ul>";
}

echo "</div>";

echo "<hr style='margin: 40px 0;'>";
echo "<p style='text-align: center; color: #6b7280; font-size: 14px;'>";
echo "Generated: " . date('Y-m-d H:i:s') . " | Uganda Results System v" . (defined('APP_VERSION') ? APP_VERSION : '1.0.0');
echo "</p>";
?>
